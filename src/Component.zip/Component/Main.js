import React from 'react'
import ImageList from './ImageList'

const Main = () => {
  return (
    <div>
        <ImageList/>
    </div>
  )
}

export default Main